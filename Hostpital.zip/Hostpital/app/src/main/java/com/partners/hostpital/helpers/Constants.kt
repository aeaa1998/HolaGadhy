package com.partners.hostpital.helpers

object Constants {
    val accessToken = "access_token"
}
