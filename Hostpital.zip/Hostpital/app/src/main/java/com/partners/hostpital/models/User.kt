package com.partners.hostpital.models

